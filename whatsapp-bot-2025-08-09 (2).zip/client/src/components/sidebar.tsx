import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  ChartBar, 
  Users, 
  Video, 
  TrendingUp, 
  Bell, 
  Settings, 
  Bot,
  Circle,
  Download
} from "lucide-react";

const navigation = [
  { name: "لوحة المعلومات", href: "/", icon: ChartBar },
  { name: "إدارة الأعضاء", href: "/members", icon: Users },
  { name: "سجل الفيديوهات", href: "/videos", icon: Video },
  { name: "التفاعل والإحصائيات", href: "/analytics", icon: TrendingUp },
  { name: "التنبيهات", href: "/notifications", icon: Bell },
  { name: "إعدادات البوت", href: "/settings", icon: Settings },
  { name: "تحميل الملفات", href: "/download", icon: Download },
];

interface SidebarProps {
  botStatus?: {
    isReady: boolean;
    qrCode: string | null;
  };
}

export default function Sidebar({ botStatus }: SidebarProps) {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-white dark:bg-gray-900 shadow-lg flex-shrink-0 border-l dark:border-gray-800" dir="rtl">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-primary-500 rounded-lg flex items-center justify-center">
            <Bot className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-800 dark:text-white">بوت ريدز</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">إدارة المجموعة</p>
          </div>
        </div>
        
        <nav className="space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href || 
              (item.href !== "/" && location.startsWith(item.href));
            
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-colors",
                  isActive
                    ? "text-primary-600 bg-primary-50 dark:bg-primary-900/20 dark:text-primary-400"
                    : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800"
                )}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.name}</span>
              </Link>
            );
          })}
        </nav>
      </div>
      
      <div className="absolute bottom-6 right-6 left-6">
        <div className={cn(
          "p-4 rounded-lg border",
          botStatus?.isReady
            ? "bg-success-50 border-success-200 dark:bg-success-900/20 dark:border-success-800"
            : "bg-warning-50 border-warning-200 dark:bg-warning-900/20 dark:border-warning-800"
        )}>
          <div className="flex items-center gap-2 mb-2">
            <Circle className={cn(
              "w-2 h-2 rounded-full",
              botStatus?.isReady 
                ? "bg-success-500 animate-pulse" 
                : "bg-warning-500"
            )} />
            <span className={cn(
              "text-sm font-medium",
              botStatus?.isReady
                ? "text-success-600 dark:text-success-400"
                : "text-warning-600 dark:text-warning-400"
            )}>
              {botStatus?.isReady ? "البوت متصل" : "البوت غير متصل"}
            </span>
          </div>
          <p className="text-xs text-gray-600 dark:text-gray-400">
            {botStatus?.isReady ? "آخر نشاط: منذ دقيقتين" : "يحاول الاتصال..."}
          </p>
        </div>
      </div>
    </div>
  );
}
